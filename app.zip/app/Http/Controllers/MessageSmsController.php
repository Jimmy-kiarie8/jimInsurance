<?php

namespace App\Http\Controllers;

use App\MessageSms;
use Illuminate\Http\Request;

class MessageSmsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MessageSms  $messageSms
     * @return \Illuminate\Http\Response
     */
    public function show(MessageSms $messageSms)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MessageSms  $messageSms
     * @return \Illuminate\Http\Response
     */
    public function edit(MessageSms $messageSms)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MessageSms  $messageSms
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MessageSms $messageSms)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MessageSms  $messageSms
     * @return \Illuminate\Http\Response
     */
    public function destroy(MessageSms $messageSms)
    {
        //
    }
}
