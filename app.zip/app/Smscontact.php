<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Smscontact extends Model
{
    //
}
