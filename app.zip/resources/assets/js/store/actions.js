export default {
    AllUsers: [],
    AllBranches: [],
}